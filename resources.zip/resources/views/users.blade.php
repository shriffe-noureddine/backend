@extends('template')

@section ('title','user Title')

@section ('content')

@if (count($allUsers))
    <ul>
        @foreach($allUsers as $oneUser)
        <li>
        {{ $oneUser->lastname }}
        </li>
        @endforeach
    </ul>
    @endif
    
@endsection