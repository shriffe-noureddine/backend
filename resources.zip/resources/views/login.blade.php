

<form action="/user" method="post">
@csrf
<input type="email" name="email" id="email">
<input type="submit" value="Login">
</form>
