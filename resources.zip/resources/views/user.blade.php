@extends ('template')

@section ('title', 'user information')

@section ('content')
    @if (count($user) === 1)
        <P>lastname : {{ $user[0]->lastname }}</P>
        <P>firstname : {{ $user[0]->firstname }}</P>
        <P>email : {{ $user[0]->email }}</P>
        @else
        <P>user not found</P>
    @endif
@endsection