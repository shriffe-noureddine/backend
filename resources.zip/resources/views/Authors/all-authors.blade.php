@extends ('template')

@section ('title', 'Authors List')

@section ('content')
    @if (count($authors) > 0)
        @foreach ($authors as $author)
            <P>name : {{ $author->name }}</P>
            <P>birthdate : {{ $author->date_of_birth }}</P>
            <P>gender : {{ $author->gender }}</P>
        @endforeach
        @else
        <P>authors not found</P>
    @endif
@endsection