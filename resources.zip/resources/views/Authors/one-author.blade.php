@extends ('template')

@section ('title', 'Authors List')

@section ('content')
    @if ($author)
        {{-- var_dump($author) --}}  
       <p>
       {{ $author->name }}
       </p>         
        @else
        <P>authors not found</P>
    @endif
@endsection