<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App;
// App\Author => we can use Author inside instead of App\Author OR we can remove use App; but
// We must call \App\Author 


class AuthorsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //$authors = DB::select('SELECT * FROM authors');
        $authors = App\Author::all();

            return view('Authors.all-authors', ['authors' => $authors]);
            
			//return view('Authors.all-authors', ['authors' => $authors]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $newAuthor = new App\Author;
     //   $newAuthor->name = $request->
        $newAuthor->save();
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //$author = App\Author::where('id',$id)->first();
        $author = App\Author::find($id);
        $books = $author->books;
        return '<pre>Author : '. $books[0]->title .'</pre>';
        // return view('Authors.one-author', ['author' => $author]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $author = App\Author::find($id);
        $author->name = "New Author's Name";

        $author->save();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //$author = App\Author::find($id);
        //$author->delete();
        App\Author::destroy($id);
    }
    
    public function example()
{
$author = App\Author::where('gender','F')->orderBy("name")->get();
}


}
