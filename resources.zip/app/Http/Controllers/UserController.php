<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;

class UserController extends Controller
{
      /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    //public function show($id)
    public function show()
    {
        $allUsers = DB::select('SELECT * FROM larausers');
        return view('users',["allUsers" => $allUsers]);
    }


    public function login (Request $request)
    {
        $user = DB::select('SELECT * FROM larausers WHERE email = ?', [$request->email]);
            return view ('user',["user" => $user]);
    }

}
