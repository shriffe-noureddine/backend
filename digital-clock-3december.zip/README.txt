A Pen created at CodePen.io. You can find this one at http://codepen.io/davidkpiano/pen/Vmyyzd.

 An original quick pen of a 3D digital clock concept with RxJS and CSS variables for #3December